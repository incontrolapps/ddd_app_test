const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BMvKVNpM.js')).default;
const imports = ["_app/immutable/nodes/2.CuFWuP6R.js","_app/immutable/chunks/DlJmpeef.js","_app/immutable/chunks/BNcx3LAd.js","_app/immutable/chunks/CCA6lnt5.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-DY_VvF1Q.js.map
