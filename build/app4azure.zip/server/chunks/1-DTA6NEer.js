const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-C0IPFalu.js')).default;
const imports = ["_app/immutable/nodes/1.DKTaGzMw.js","_app/immutable/chunks/DlJmpeef.js","_app/immutable/chunks/BNcx3LAd.js","_app/immutable/chunks/CCA6lnt5.js","_app/immutable/chunks/CF1z4Vv1.js","_app/immutable/chunks/Bj8ubINB.js","_app/immutable/chunks/B7c6h4Q9.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DTA6NEer.js.map
