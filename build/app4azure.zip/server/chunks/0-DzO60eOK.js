const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./layout.svelte-4V-_rMCU.js')).default;
const imports = ["_app/immutable/nodes/0.Co75Ri7i.js","_app/immutable/chunks/DlJmpeef.js","_app/immutable/chunks/BNcx3LAd.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-DzO60eOK.js.map
